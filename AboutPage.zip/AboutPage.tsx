import React from 'react';
import { motion } from 'motion/react';
import { User, Award, Terminal, CheckCircle2, MessageSquare, Code2, Zap, Cpu, Sparkles, BookOpen, Layers } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const AboutPage: React.FC = () => {
  const { openContactModal } = useTheme();

  const timeline = [
    {
      year: '2024 — Present',
      title: 'Senior Full-Stack Architect',
      company: 'Freelance & Bespoke Web Solutions',
      description: 'Delivering end-to-end web applications, e-commerce platforms, and high-performance landing pages for international clients with 99+ Lighthouse speed scores.'
    },
    {
      year: '2022 — 2024',
      title: 'Lead Frontend & Creative Motion Engineer',
      company: 'Apex Digital Systems',
      description: 'Architected real-time WebSocket dashboard suites, canvas graphics engines, and micro-interaction animation design systems in React and TypeScript.'
    },
    {
      year: '2020 — 2022',
      title: 'Full-Stack Web Developer',
      company: 'NextGen Web Studio',
      description: 'Developed high-conversion e-commerce storefronts, REST API services, Node.js backend pipelines, and Stripe payment gateway integrations.'
    }
  ];

  const toolbelt = [
    { category: 'Frontend Architecture', tools: ['React 19', 'TypeScript', 'Tailwind CSS v4', 'Next.js Patterns', 'Zustand State', 'Redux Toolkit'] },
    { category: 'Backend & APIs', tools: ['Node.js', 'Express', 'RESTful Services', 'GraphQL', 'WebSockets', 'Rate Limiting & Auth'] },
    { category: 'Graphics & Motion', tools: ['Framer Motion / Motion', 'HTML5 Canvas 2D', 'Three.js / WebGL', 'SVG Path Animations'] },
    { category: 'Performance & DevOps', tools: ['Core Web Vitals', 'Docker', 'Vite & esbuild', 'Schema.org SEO', 'GitHub Actions'] }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-20">
      {/* Bio Header */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Profile Details */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:col-span-7 space-y-6"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-semibold uppercase tracking-wider">
            <User className="w-3.5 h-3.5" /> Full-Stack Developer Profile
          </div>

          <h1 className="text-4xl sm:text-6xl font-heading font-extrabold text-textDark dark:text-textLight tracking-tight">
            Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-amber-500">Wali Ali</span>
          </h1>

          <p className="text-base sm:text-lg text-textMuted leading-relaxed">
            I specialize in crafting web applications that combine high-end aesthetic visual craft with resilient, zero-defect engineering logic. With over ~50 completed projects across Web Applications, E-Commerce, High-Performance Landing Pages, and Interactive 3D/Canvas Experiences, my goal is to turn complex functional requirements into fast, delightful software.
          </p>

          <div className="pt-2 flex flex-wrap gap-4">
            <button onClick={() => openContactModal('General Inquiry')} className="btn-creative-primary text-xs">
              <MessageSquare className="w-4 h-4" /> Get in Touch
            </button>
            <a href="mailto:waliali1292@gmail.com" className="btn-creative-outline text-xs">
              Email Directly: waliali1292@gmail.com
            </a>
          </div>
        </motion.div>

        {/* Developer Avatar / Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="lg:col-span-5"
        >
          <div className="glass-card p-6 border-emerald-500/30 space-y-6 relative overflow-hidden">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-amber-500 p-0.5">
                <div className="w-full h-full rounded-[14px] bg-cardLight dark:bg-cardDark flex items-center justify-center font-heading font-extrabold text-2xl text-emerald-500">
                  WA
                </div>
              </div>
              <div>
                <h3 className="font-heading font-bold text-xl text-textDark dark:text-textLight">Wali Ali</h3>
                <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">Senior Web Developer</span>
              </div>
            </div>

            <div className="space-y-3 text-xs text-textMuted border-t border-emerald-500/10 pt-4">
              <div className="flex justify-between">
                <span>Location:</span>
                <span className="font-semibold text-textDark dark:text-textLight">Available Globally (Remote)</span>
              </div>
              <div className="flex justify-between">
                <span>Core Stack:</span>
                <span className="font-semibold text-textDark dark:text-textLight">React, TypeScript, Express, Tailwind</span>
              </div>
              <div className="flex justify-between">
                <span>Primary Email:</span>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">waliali1292@gmail.com</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Tech Toolbelt */}
      <div className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-3xl font-heading font-bold text-textDark dark:text-textLight">Technical Toolbelt</h2>
          <p className="text-xs text-textMuted">Proven modern stack libraries and engineering practices.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {toolbelt.map((section, idx) => (
            <div key={idx} className="glass-card p-6 space-y-4">
              <h3 className="font-heading font-bold text-lg text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
                <Code2 className="w-5 h-5 text-amber-500" /> {section.category}
              </h3>
              <div className="flex flex-wrap gap-2">
                {section.tools.map((t, i) => (
                  <span key={i} className="px-3 py-1 rounded-xl text-xs font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                    {t}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Experience Timeline */}
      <div className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-3xl font-heading font-bold text-textDark dark:text-textLight">Career & Engineering History</h2>
          <p className="text-xs text-textMuted">Milestones in web development and software design.</p>
        </div>

        <div className="space-y-6 max-w-3xl mx-auto">
          {timeline.map((item, idx) => (
            <div key={idx} className="p-6 rounded-3xl bg-cardLight dark:bg-cardDark border border-emerald-500/20 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="font-heading font-bold text-lg text-textDark dark:text-textLight">{item.title}</h3>
                <span className="text-xs font-mono px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-semibold">{item.year}</span>
              </div>
              <p className="text-xs font-semibold text-amber-500">{item.company}</p>
              <p className="text-xs text-textMuted leading-relaxed">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
